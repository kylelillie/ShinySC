# ShinySC
A straight-forward helper to build customized table links to Statistics Canada data tables

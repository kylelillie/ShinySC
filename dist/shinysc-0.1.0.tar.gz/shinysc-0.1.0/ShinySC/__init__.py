import ShinySC
ShinySC.main()
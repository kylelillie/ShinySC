import re
import json
import requests
import urllib.parse
from datetime import datetime

_cached_metadata = None
_cached_cube_list = None

_codes = requests.get('https://www150.statcan.gc.ca/t1/wds/rest/getCodeSets')
_codes = _codes.json()

def _fmt_id(id):

    id = str(id)

    if id.count('-') == 3:
        a,b,c,d = id.split('-')
        return a+b+c
    
    if id.count('-') == 2:
        a,b,c = id.split('-')
        return a+b+c

    if len(id) == 10:
        return id[:8]
    
    return id

def _vali_date(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        return True
    
    except ValueError:
        return False

def _cube_list(id='',lang='en'):
    """
    Retrieves information about a cube (table).

    Args:
        id (int or str): The product ID (PID)
        lang (str): The language ('en' or 'fr')
    """

    global _cached_cube_list

    try:
        if _cached_cube_list == None:
            url = "https://www150.statcan.gc.ca/t1/wds/rest/getAllCubesList"
            resp = requests.get(url)
            table = resp.json()
            _cached_cube_list = table

        else:
            table = _cached_cube_list

    except Exception as e:
        print('Failed to find "getAllCubesList" on WDS')

    if id == '':
        return table

    for i in table:
        if i['productId'] == id: return i
    else:
        print(f'Table {id} not found.')

def _remove_lang(obj,language):
    
    language = 'En' if language == 'en' else 'Fr'

    if isinstance(obj, dict):
        
        obj = {k: _remove_lang(v,language) for k, v in obj.items() if not k.endswith(language)}

        for k in obj.keys():
            if isinstance(obj[k],list):
                if len(obj[k]) > 0:
                    if isinstance(obj[k][0],dict):
                        obj[k] = [_remove_lang(i,language) for i in obj[k]]
        return obj
    
    else:
        return obj

def _search_json(obj: dict={}, term: str='', mode: str='AND'):
    """
    Recursively search JSON-like structures.
    Keep entries if:
      - key contains term
      - OR value contains term
      - OR nested match
      - OR sibling key contains "code" when any match occurs in the same dict
    """

    mode = mode.upper()

    if mode == "OR":
        terms = [t.strip() for t in term.split(",") if t.strip()]
        pattern = re.compile("|".join(map(re.escape, terms)), re.IGNORECASE | re.DOTALL)

    if mode == "AND":
        query = [t.strip() for t in term.split(",") if t.strip()]
        regex = "".join(
            rf"(?=.*(?:^|\W){re.escape(t)}(?:\W|$))"
            for t in query
        )
        pattern = re.compile(regex, re.IGNORECASE | re.DOTALL)

    # Case 1: dict
    if isinstance(obj, dict):
        matches = {}              # matches found in this dict
        matched_in_dict = False   # flag so we can keep sibling "code" keys

        # First pass: detect matches
        child_results = {}

        for k, v in obj.items():
            
            key_match = bool(pattern.search(k))
            value_match = isinstance(v, str) and bool(pattern.search(v))
            
            nested = None

            if isinstance(v, (dict, list)):
                nested = _search_json(v, term, mode)

            # If this entry matches directly or via nested
            if key_match or value_match or nested:
                matched_in_dict = True
                child_results[k] = nested if nested is not None else v

        # Second pass: if any match happened, also keep sibling "code" keys
        if matched_in_dict:
            for k, v in obj.items():
                if "Code" in k and k not in child_results:
                    print(k,v)
                    child_results[k] = v

        return child_results if child_results else None

    # Case 2: list
    elif isinstance(obj, list):
        results = []
        for item in obj:
            nested = _search_json(item, term, mode)
            #value_match = isinstance(item, str) and term in item
            value_match = isinstance(item, str) and bool(pattern.search(item))

            if nested is not None or value_match:
                results.append(nested if nested is not None else item)

        return results if results else None

    # Case 3: primitive
    else:
        #if isinstance(obj, str) and term in obj:
        print(obj)
        try:
            if isinstance(obj, str) and bool(re.search(obj)):
                return obj
        except:
            pass

        return None

def _parse_dim(x,full=True):

    tmp = {}
    sel = []

    if full:
        for i in x:
            try:
                tmp[i['dimensionNameEn']] = i['member']
                j = []
                for k in i['member']:
                    j.append(k['memberId'])
            except:
                tmp[i['dimensionNameEn']] = i['hasUom']

            sel.append(j)
    else:
        pass
    
    return tmp,sel

def _parse_filters(filters,id,lang='en'):
    """
    Takes user-defined filters as a dictionary and
    transforms it to use in the StatCan URL.

    Args:
        filters (dict): User-defined filters
    """
    #Iterate over dict; put it in same order metadata has them;
    #Then convert selected items into their numeric entries as nested list
    #--> Convert dimensionName to dimensionPositionId; this lets us put in right order
    #-->---> Convert members' memberNameEn(Fr) to memberId
    #There will be some "easy" filters, like '503' to select all CMAs in geography
    #...though I guess that would be applied after the table is downloaded

    tmp = full_metadata(id)
    dim = tmp['dimension']

    new_filters = []

    for i in range(0,len(dim)):

        dim_name = dim[i][f'dimensionName{lang.capitalize()}']

        if dim_name in filters:

            selected_names = filters[dim_name]
            selected_ids = []

            for j in dim[i]['member']:

                if j[f'memberName{lang.capitalize()}'] in selected_names:
                    selected_ids.append(j['memberId'])

            new_filters.append(selected_ids)

        else:
            #Select all members if not specified in filters
            selected_ids = []
            for j in dim[i]['member']:
                selected_ids.append(j['memberId'])
            new_filters.append(selected_ids)
    
    raw = json.dumps(new_filters, separators=(',',':'))
    enc = urllib.parse.quote(raw)

    return enc

def full_metadata(id, timeout=30, lang='en', special=[]):
    """
    Retrieves metadata for a cube (table) from Statistics Canada WDS in JSON format.

    :param id (str): productId
    :param timeout (int): Timeout in seconds for the HTTP request.
    :param lang (str): which langauge you wish to get data in ('en'[default] or 'fr')
    """

    if (id != '') & ((len(str(id)) != 8) | (any(c.isalpha() for c in str(id)))): raise ValueError('productId must be 8 digits.')

    endpoint = "https://www150.statcan.gc.ca/t1/wds/rest/getCubeMetadata"

    # Prepare payload as list of dicts, per documentation example. :contentReference[oaicite:2]{index=2}
    payload = [
        {
            "productId": str(id)
        }
    ]

    headers = {
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(endpoint, headers=headers, json=payload, timeout=timeout)
        response.raise_for_status()
        data = response.json()
   
        # Check for status
        if data[0]["status"] != "SUCCESS":
            raise RuntimeError(f"Request returned non-SUCCESS status: {data}")
        
        if lang == 'en':
            return _remove_lang(data[0]['object'],'Fr')
        
        elif lang == 'fr':
            return _remove_lang(data[0]['object'],'En')
        
        else:
            return data[0]['object']
    
    except requests.RequestException as e:
        raise RuntimeError(f"HTTP request failed: {e}") from e
    
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Failed to parse JSON response: {e}") from e

def simple_metadata(id, lang='en'):
    """
    Retrieves and displays simplified metadata for a cube (table).\n
    This will only show productId, cubeTitle, cubeEndDate, cubeStartDate, and a simplified dimension.

    :param id (str): productId
    :param lang (str): which langauge you wish to get data in ('en'[default] or 'fr')
    """

    if (id != '') & ((len(str(id)) != 8) | (any(c.isalpha() for c in str(id)))): raise ValueError('productId must be 8 digits.')

    meta = full_metadata(id,30,lang)

    keep = ['productId',f'cubeTitle{lang.capitalize}','cubeEndDate','cubeStartDate','dimension']

    obj = {k:v for k,v in meta.items() if k in keep}

    return obj

def help():
    print("""
---------------------------------------------------------

describe(): provides key information about a table to help you build a custom query
make_url(): builds a custom URL to download data from StatCan WDS
list_tables (): ists all active tables available on StatCan WDS
help(): displays this help message
simple_metadata(): retrieves simplified metadata for a table
full_metadata(): retrieves full metadata for a table
search (): earches for tables matching your criteria
update_list(): checks for recently updated tables


If you already know the productId and filters for the table 
you want, simply call:
          
          url = ShinySC.make_url(id={id}, filters={...})

Addtionally, you can specify date ranges or number of recent periods:
          
            url = ShinySC.make_url(id={id}, periods=5)
            url = ShinySC.make_url(id={id}, start='2020-01-01',end='2022-01-01')

If you don't know what table you want, you can programmatically
search for tables that match your criteria using these criteria:
          
        ShinySC.search(query,last_updated,dates,status)

        query: comma-separated terms to search for in table names, descriptions, and surveys
        last_updated: 'YYYY-MM-DD' to search tables updated on or after this date
        dates: list of two strings [start_date,end_date] to filter tables by date range
        status: 'active' or 'archived' tables (default is 'active')
          
Call ShinySC.describe(productId) to see available dimensionsthat can be used for filtering.
          
Call ShinySC.update_list(date='YYYY-MM-DD') to see recently updated tables for a specfiic date.
Add in a productId to see if that specific table was updated on that date.
          
          ShinySC.update_list(id=35100003,date='2023-01-01')
          
This library makes use of these endpoints:
https://www150.statcan.gc.ca/t1/wds/rest/getCodeSets  
https://www150.statcan.gc.ca/t1/wds/rest/getAllCubesList  
https://www150.statcan.gc.ca/t1/wds/rest/getCubeMetadata  
https://www150.statcan.gc.ca/t1/wds/rest/getChangedCubeList  
          
---------------------------------------------------------
""")

def describe(id, lang='en'):
    """
    Quickly get key information to help you build a custom query.

    :param id (str): productId
    :param lang (str): which langauge you wish to get data in ('en'[default] or 'fr')
    """

    if (id != '') & ((len(str(id)) != 8) | (any(c.isalpha() for c in str(id)))): raise ValueError('productId must be 8 digits.')

    attributes = {}

    md = full_metadata(id,30,lang)

    attributes['name'] = md[f'cubeTitle{lang.capitalize()}']
    attributes['dataPoints'] = md['nbDatapointsCube']
    attributes['productId'] = id
    attributes['status'] = 'Active' if md['archiveStatusCode'] == '2' else 'Archived'
    attributes['dataDateRange'] = [md['cubeStartDate'],md['cubeEndDate']]
    attributes['lastUpdated'] = md['releaseTime']
    attributes['subject'] = md['subjectCode']
    attributes['dimensions'] = [
        {i[f'dimensionName{lang.capitalize()}']:[j[f'memberName{lang.capitalize()}'] for j in i['member']]} for i in md['dimension']
        ]

    return attributes

def make_url(id: int='',periods: int='',start: str='',end: str='',filters={},lang: str='en'):
    """
    Downloads a table from Statistics Canada using custom filters.
    Default language is English ('en')
    Returns a URL that can be downloaded with your favourite library.

    Args:
        :param id (int, str): productId
        :param periods (int): number of recent periods you wish to download (default is 1)
        :param start (str): desired start date for data series (YYYY-MM-DD)
        :param end (str): desired end date for data series (YYYY-MM-DD)
        :param full (bool): download the full table or not (default True)
        :param filters (dict): filters you wish to apply ('attribute':[...],...)
        :param lang (str): which langauge you wish to get data in ('en'[default] or 'fr')
    """
    global _cached_metadata
    full = False

    #Validate inputs
    if (id != '') & ((len(str(id)) != 8) | (any(c.isalpha() for c in str(id)))): raise ValueError('productId must be 8 digits.')
    if lang not in ['en','fr']: raise ValueError('Language must be "en" or "fr".')
    if (periods != '') & (not isinstance(periods,int)): raise TypeError('Must be integer number of periods to download.')

    if (start != '') & (not(_vali_date(start))): raise ValueError('Must be a valid date in the format YYYY-MM-DD.')
    if (start > datetime.now().strftime('%Y-%m-%d')): raise ValueError('Invalid start date. Cannot be in the future.')
    if (start > end) & (end != ''): raise ValueError('Start date cannot be after end date.')

    if (end != '') & (not(_vali_date(end))): raise ValueError('Must be a valid date in the format YYYY-MM-DD.')
    if (end < start) & (start != ''): raise ValueError('End date cannot be after start date.')

    if not isinstance(filters,dict): raise ValueError('Filters must be a dictionary of filterName:[values,...].')

    try:
        if _cached_metadata == None:
            md = full_metadata(id,30,lang)

        else:
            md = _cached_metadata
    except:
        print('Invalid productId.')
        return ''

    #tablename = md['cubeTitleEn']

    archived = md['archiveStatusCode']
    lastUpdated = md['releaseTime']

    if archived == '1': print(f'ADVISORY: This table has been archived and does not get updated. Last updated: {lastUpdated}')

    if filters == {} and not full and periods == '' and start == '' and end == '':
        print('ADVISORY: No filters specified. Generating URL for the full table. Full tables can be very large.')
        full = True

    if full:
        dim = md['dimension']
        dim,selected = _parse_dim(dim,full)
        raw = json.dumps(selected, separators=(',',':'))
        filters = urllib.parse.quote(raw)

    else:
        filters = _parse_filters(filters,id,lang)

    #Date filter stuff
    if (periods == '') & (start == '') & (end == ''):
        print('ADVISORY: No date range or periods specified.\nDefaulting to all periods, which may be a large amount of data.')
        start = md['cubeStartDate']
        end = md['cubeEndDate']

    url = f'https://www150.statcan.gc.ca/t1/tbl1/en/dtl!downloadDbLoadingData-nonTraduit.action?pid={id}01&latestN={periods}&startDate={start}&endDate={end}&csvLocale={lang}&selectedMembers={filters}&checkedLevels='

    return url

def search(query='',last_updated='',data_dates=[],status='active',mode='AND',lang='en'):
    """
    Docstring for find_tables
    
    :param query (str): Comma-delimited terms to search for in table names, descriptions, and surveys
    :param status (str): Active (default) or Archived
    :param last_updated (str): Only return tables updated after this date (YYYY-MM-DD)
    :param data_dates ([str,str]): Only return tables with data in this date range (YYYY-MM-DD)
    :param mode (str): 'AND'[default] or 'OR' search mode for query terms
    :param lang (str): Language ('en' or 'fr')
    """

    global _codes

    lang = lang.lower()
    mode = mode.upper()

    #Validate inputs
    if query == '': raise ValueError('Query cannot be empty.')
    if query.count(',') >= 10: raise ValueError('Maximum of 10 search terms allowed.')
    if query.count(',,') > 0: raise ValueError('Empty search terms are not allowed.')
    if query.startswith(',') or query.endswith(','): raise ValueError('Empty search terms are not allowed.')

    if lang not in ['en','fr']: raise ValueError('Language must be "en" or "fr".')
    if status.lower() not in ['active','archived']: raise ValueError('Status must be "active" or "archived".')
    if mode.upper() not in ['AND','OR']: raise ValueError('Mode must be "AND" or "OR".')

    if (last_updated != '') & (not(_vali_date(last_updated))): raise ValueError('Must be a valid date in the format YYYY-MM-DD.')

    if data_dates != []:

        if len(data_dates) == 2:
            
            start = data_dates[0]
            end = data_dates[1]

            if (start != '') & (not(_vali_date(start))): raise ValueError('Starting data must be a valid date in the format YYYY-MM-DD.')
            if (start > datetime.now().strftime('%Y-%m-%d')): raise ValueError('Invalid start date. Cannot be in the future.')
            if (start > end) & (end != ''): raise ValueError('Start date cannot be after end date.')

            if (end != '') & (not(_vali_date(end))): raise ValueError('End data must be a valid date in the format YYYY-MM-DD.')
            if (end < start) & (start != ''): raise ValueError('End date cannot be after start date.')

    status = status.lower()
    mode = mode.upper()
    lang = lang.lower()

    if status == 'active':
        status = '2'
    elif status == 'archived':
        status = '1'
    else:
        raise ValueError('Status must be "active" or "archived".')

    local_codes = _remove_lang(_codes,'Fr' if lang == 'en' else 'En')
    local_codes = _search_json(local_codes,query,mode)

    parsed_local_codes = {}
    
    if local_codes != None:

        for k in local_codes['object'].keys():
            parsed_local_codes[k] = []
            for i in local_codes['object'][k]:
                try:
                    parsed_local_codes[k].append(i[f'{k}Code'])
                except:
                    pass
    
    tables = _cube_list()
    filtered_tables = []

    if mode == "OR":
        terms = [t.strip() for t in query.split(",") if t.strip()]
        pattern = re.compile("|".join(map(re.escape, terms)), re.IGNORECASE | re.DOTALL)

    if mode == "AND":
        query = [t.strip() for t in query.split(",") if t.strip()]
        regex = "".join(
            rf"(?=.*(?:^|\W){re.escape(t)}(?:\W|$))"
            for t in query
        )
        pattern = re.compile(regex, re.IGNORECASE | re.DOTALL)

    for t in tables:

        cubeTitle = f'cubeTitle{lang.capitalize()}'
        released = t['releaseTime'][:10]
        startDate = t['cubeStartDate']
        endDate = t['cubeEndDate']

        if pattern.search(t[cubeTitle]):
            if t['archived'] == status:

                # prevent duplicates
                existing_ids = {list(d.keys())[0] for d in filtered_tables}
                if t['productId'] in existing_ids:
                    return  # or continue if in a loop

                if last_updated:
                    released_date = datetime.strptime(released, "%Y-%m-%d").date()
                    last_updated_date = datetime.strptime(last_updated, "%Y-%m-%d").date()

                    if released_date >= last_updated_date:
                        filtered_tables.append({t['productId']: t[cubeTitle]})
                else:
                    filtered_tables.append({t['productId']: t[cubeTitle]})

        for k in parsed_local_codes.keys():

            if  (t['productId'] not in filtered_tables) & (t['archived'] == status):
                if (k == 'subject') & (len(parsed_local_codes[k]) > 0) & ('subjectCode' in t):
                    try:
                        filtered_tables.append({t['productId']:t[f'cubeTitle{lang.capitalize()}']}) if set(parsed_local_codes[k]).intersection(set(t['subjectCode'])) else None
                    except:
                        pass

                if (k == 'survey') & (len(parsed_local_codes[k]) > 0) & (t['surveyCode'] != None):
                    try:
                        filtered_tables.append({t['productId']:t[f'cubeTitle{lang.capitalize()}']}) if set(parsed_local_codes[k]).intersection(set(t['surveyCode'])) else None
                    except:
                        pass

    print(f'Found {len(filtered_tables)} tables matching search criteria, "{query}".\n')

    return filtered_tables

def update_list(id='',date=''):
    """
    :param id (str): Product ID of the table to check
    :param date (str): Date in the format YYYY-MM-DD to check for changes
    """

    #if they input just a date in the id field, treat it as date
    if (id.count('-') == 2) & (date == '') & (_vali_date(id)):
        date = id
        id = ''

    if (id != '') & ((len(str(id)) != 8) | (any(c.isalpha() for c in str(id)))): raise ValueError('productId must be 8 digits.')
    if (date != '') & (not(_vali_date(date))): raise ValueError('Must be a valid date in the format YYYY-MM-DD.')

    #If no date provided, use today's date
    if date == '':
        date = datetime.now().strftime('%Y-%m-%d')

    url = f"https://www150.statcan.gc.ca/t1/wds/rest/getChangedCubeList/{date}"
    resp = requests.get(url)
    tables = resp.json()
 
    if id != '':
        for i in tables['object']:
            if i['productId'] == int(id):
                return True
            else:
                return False
            
    elif id == '':
        return tables['object']

def list_tables(lang='en'):

    """
    :param lang (str): Language of the table to return ('en' or 'fr')
    """

    lang = lang.lower()
    if lang not in ['en','fr']: raise ValueError('Language must be "en" or "fr".')

    url = "https://www150.statcan.gc.ca/t1/wds/rest/getAllCubesList"
    resp = requests.get(url)
    tables = resp.json()

    df = pd.DataFrame(tables)

    if lang == 'en':
        df = df[[x for x in df.columns if x if 'Fr' not in x]]
    elif lang == 'fr':
        df = df[[x for x in df.columns if x if 'En' not in x]]

    df = df[df['archived'] == '2']

    archived_tables = df[df['archived'] == '1']
    active_tables = df[df['archived'] == '2']

    card_css = "border:1px solid black;margin:10px;padding:10px;background:white;max-width:200px;border-radius:3px;color:black;"
    n = 2

    count = 0

    for p in tables:

        id = p['productId']
        endDate = datetime.fromisoformat(p['cubeEndDate'].replace("Z", "+00:00")).replace(tzinfo=None)

        if p['archived'] == '2':

            metadata = full_metadata(id)
            num_dimensions = len(metadata['dimension'])
            data = metadata['dimension']

            tablename = p['cubeTitleEn']
            dim = p['dimensions']
            dim,selected = _parse_dim(dim)

            raw = json.dumps(selected, separators=(',',':'))
            enc = urllib.parse.quote(raw)

            num_param = len(data)

            attributes = {}
            attributes['Table Name'] = tablename

            for i in range(0,num_param):

                sub_size = len(data[i]['member'])
                top_name = data[i]['dimensionNameEn']

                for j in range(0,sub_size):
                    
                    #print(data[i]['member'][j])

                    name = data[i]['member'][j]['memberNameEn']
                    classification = data[i]['member'][j]['classificationCode']

                    if top_name in attributes:
                        attributes[top_name].append(name)
                    else:
                        attributes[top_name] = [name]

            print(id,' - ',tablename,'\n',attributes)
            #get_table(id=id,n=n,enc=enc)#region_type='503')
            
            count += 1

